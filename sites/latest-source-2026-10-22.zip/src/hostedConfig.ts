export const FILE_ONLY_HOSTED = true;
